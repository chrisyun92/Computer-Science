# CS 170 Fall 2019 Project
First, place all the inputs in a folder called 'inputs'.
Then, to run our code, simply go into your terminal and run the bash script
```
./solve-all-inputs.bat
```