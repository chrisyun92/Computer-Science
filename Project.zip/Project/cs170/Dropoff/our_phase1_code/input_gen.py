# CITE: https://stackoverflow.com/questions/46346143/generating-a-complete-graph-in-metric-space

import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
import sys
import random

def create_input_graph(num_locations, num_tas):
	D = 2
	positions = np.random.rand(num_locations, D)
	differences = positions[:, None, :] - positions[None, :, :]
	distances = np.sqrt(np.sum(differences**2, axis=-1))*100000000 # euclidean

	# create a weighted, directed graph in networkx
	graph = nx.from_numpy_matrix(distances, create_using=nx.DiGraph())

	array = nx.convert_matrix.to_numpy_matrix(graph).tolist()
	return array


def prune_edges_on_array(array, probability_to_prune_edge=0.75):
	row_num_edges = 0
	col_num_edges = 0
	length_of_row = len(array[0])
	length_of_col = len(array[0])


	for element in range(length_of_col):
		array[element][element] = 'x'

	for i in range(length_of_row):
		for j in range(length_of_col):
			row_num_edges = 0
			col_num_edges = 0
			if random.random() < probability_to_prune_edge:
				for element in range(length_of_row):
					if array[i][element] != 'x':
						row_num_edges += 1

				for element in range(length_of_col):
					if array[j][element] != 'x':
						col_num_edges += 1
				if row_num_edges > 1 and col_num_edges > 1:
					array[i][j] = 'x'
					array[j][i] = 'x'




	return array

def is_array_symmetric(array):
	symmetric = True
	for row in range(len(array[0])):
		for col in range(len(array[0])):
			if array[row][col] != array[col][row]:
				symmetric = False
	return symmetric


def print_numpy_matrix(array):
	for row in array:
		for i, elt in enumerate(row):
			if elt != 'x':
				if i == len(array) - 1:
					print(str(np.round(elt, 5)), end = "")
				else:
					print(str(np.round(elt, 5)), end = " ")
			else:
				if i == len(array) - 1:
					print('x', end = "")
				else:
					print('x', end = " ")
		print()

def print_numpy_array(array):
	for i, elt in enumerate(array):
		if i == len(array) - 1:
			print(elt, end="")
		else:
			print(elt, end=" ")
	print()


def read_locations(num_locations):
	with open('./cities.in') as f:
		locations = f.read().splitlines()
	return locations[:num_locations]

def get_ta_locations(num_tas, locations):
	tas = np.random.choice(locations, size=num_tas, replace=False)
	return tas

# arguments
# 1st: number of locations |L|
# 2nd: number of TAs
def main():
	#allows us to put commands in the terminal, specifically the number of vertices in our graph and the homes of the TA's
	num_locations, num_tas = int(sys.argv[1]), int(sys.argv[2])

	#Prints in the format for the project: the number of locations, number of homes, the list of locations, the list of homes, and the last 3 lines generate a graph that is then pruned
	print(num_locations)
	print(num_tas)
	locations = read_locations(num_locations)
	print_numpy_array(locations)
	print_numpy_array(get_ta_locations(num_tas, locations))
	print_numpy_array(np.random.choice(locations, size=1))
	array = create_input_graph(num_locations, num_tas)
	array = prune_edges_on_array(array)
	print_numpy_matrix(array)




main()
