import os
import sys
sys.path.append('..')
sys.path.append('../..')
import argparse
import utils
import matplotlib.pyplot as plt
import math
import copy


from student_utils import *
"""
======================================================================
  Complete the following function.
======================================================================
"""

def solve(list_of_locations, list_of_homes, starting_car_location, adjacency_matrix, params=[]):
    """
    Write your algorithm here.
    Input:
        list_of_locations: A list of locations such that node i of the graph corresponds to name at index i of the list
        list_of_homes: A list of homes
        starting_car_location: The name of the starting location for the car
        adjacency_matrix: The adjacency matrix from the input file
    Output:
        A list of locations representing the car path
        A dictionary mapping drop-off location to a list of homes of TAs that got off at that particular location
        NOTE: both outputs should be in terms of indices not the names of the locations themselves
    """
    best_algorithm, best_car_path, best_drop_offs, best_cost = None, None, None, float('inf')

    alg_number = 1
    for algorithm in [alg1, alg2, alg3, alg4, alg5, alg6]:
        car_path, drop_offs = algorithm(list_of_locations, list_of_homes, starting_car_location, adjacency_matrix, params)
        solution_cost = cost_of_solution(adjacency_matrix_to_graph(adjacency_matrix)[0], car_path, drop_offs)[0]
        if solution_cost < best_cost:
            best_algorithm, best_car_path, best_drop_offs, best_cost = alg_number, car_path, drop_offs, solution_cost

        print(f'The cost of algorithm #{alg_number} is {solution_cost}!')
        alg_number += 1

    print(f'The winner was algorithm #{best_algorithm} with a cost of {best_cost}!\n')
    # draw_graph(adjacency_matrix_to_graph(adjacency_matrix)[0])
    return best_car_path, best_drop_offs


"""
Algorithm 1 as defined in our algorithms document.
Satish drops everyone off at the start.
"""
def alg1(list_of_locations, list_of_homes, starting_car_location, adjacency_matrix, params=[]):
    # Makes a list of just the starting car location's index
    car_path = convert_locations_to_indices([starting_car_location], list_of_locations)

    # Makes a dictionary mapping the starting car location's index -> list of all home indices
    drop_offs = {car_path[0]: convert_locations_to_indices(list_of_homes, list_of_locations)}

    return car_path, drop_offs

"""
Algorithm 2 as defined in our algorithms document.
Satish takes a greedy tour.
"""
def alg2(list_of_locations, list_of_homes, starting_car_location, adjacency_matrix, params=[]):
    starting_car_location = list_of_locations.index(starting_car_location)
    homes_to_visit = convert_locations_to_indices(list_of_homes, list_of_locations)
    G = adjacency_matrix_to_graph(adjacency_matrix)[0]
    shortest = dict(nx.floyd_warshall(G))


    car_path = [starting_car_location]
    current_location = starting_car_location
    while homes_to_visit != []:
        distances_to_homes = [shortest[current_location][home] for home in homes_to_visit]
        next_location = homes_to_visit.pop(np.argmin(distances_to_homes))
        car_path.extend(nx.shortest_path(G, source=current_location, target=next_location, weight='weight')[1:])
        current_location = next_location

    car_path.extend(nx.shortest_path(G, source=current_location, target=starting_car_location, weight='weight')[1:])

    drop_offs = {home:[home] for home in convert_locations_to_indices(list_of_homes, list_of_locations)}

    # Optimize traversal
    car_path, drop_offs = optimize_graph(car_path, drop_offs, G)

    return car_path, drop_offs


"""
Algorithm 3 as defined in our algorithms document.
Satish uses a TSP approximation, with some added optimizations to try to cut out excess traversing.
"""
def alg3(list_of_locations, list_of_homes, starting_car_location, adjacency_matrix, params=[]):
    starting_car_location = list_of_locations.index(starting_car_location)
    homes_to_visit = convert_locations_to_indices(list_of_homes, list_of_locations)

    G = adjacency_matrix_to_graph(adjacency_matrix)[0]
    MST = nx.minimum_spanning_tree(G)
    dfs_list = list(nx.dfs_edges(MST, source=starting_car_location))

    # Construct DFS traversal list
    new_dfs_list = list(dfs_list[0])
    for i in range(1, len(dfs_list)):
        if dfs_list[i-1][1] != dfs_list[i][0]:
            new_dfs_list.extend(nx.shortest_path(MST, source=dfs_list[i-1][1], target=dfs_list[i][0])[1:])
        new_dfs_list.append(dfs_list[i][1])
    new_dfs_list.extend(nx.shortest_path(MST, source=new_dfs_list[-1], target=starting_car_location)[1:])

    # Construct drop off list
    drop_offs = {home:[home] for home in convert_locations_to_indices(list_of_homes, list_of_locations)}

    # Optimize DFS traversal
    new_dfs_list, drop_offs = optimize_graph(new_dfs_list, drop_offs, G)
     
    return new_dfs_list, drop_offs



def alg4(list_of_locations, list_of_homes, starting_car_location, adjacency_matrix, params=[]):
    starting_car_location = list_of_locations.index(starting_car_location)
    homes_to_visit = convert_locations_to_indices(list_of_homes, list_of_locations)
    locations = list(range(len(list_of_locations)))

    G = adjacency_matrix_to_graph(adjacency_matrix)[0]
    K = max(1, int(5/6* len(homes_to_visit))) # SET THIS VARIABLE
    shortest = dict(nx.floyd_warshall(G))

    # Assign cluster centers
    mu0 = starting_car_location
    mus = [mu0]
    while len(mus) < K:
        farthest_vertex = None
        farthest_vertex_length = float('-inf')
        for vertex in locations:
            dist_to_mus = min([shortest[vertex][mu] for mu in mus])
            if dist_to_mus > farthest_vertex_length:
                farthest_vertex_length = dist_to_mus
                farthest_vertex = vertex
        mus.append(farthest_vertex)


    # Assign homes to cluster centers
    clusters = [[] for _ in range(K)]
    for home in homes_to_visit:
        closest_cluster = np.argmin([shortest[home][mu] for mu in mus])
        clusters[closest_cluster].append(home)

    # Trim clusters that have no TAs being dropped off and form a drop_offs list
    mus_trimmed = []
    drop_offs = {}
    for i in range(K):
        if clusters[i] != []:
            drop_offs[mus[i]] = clusters[i]
            mus_trimmed.append(mus[i])

    # Find shortest path through cluster centers
    car_path = [starting_car_location]
    current_location = starting_car_location
    while mus_trimmed != []:
        closest_mu = np.argmin([shortest[current_location][mu] for mu in mus_trimmed])
        next_location = mus_trimmed.pop(closest_mu)
        car_path.extend(nx.shortest_path(G, source=current_location, target=next_location, weight='weight')[1:])
        current_location = next_location

    car_path.extend(nx.shortest_path(G, source=current_location, target=starting_car_location, weight='weight')[1:])

    car_path, drop_offs = optimize_graph(car_path, drop_offs, G)
    return car_path, drop_offs


"""
Algorithm 5 as defined in our algorithms document.
Satish does some funky stuff with the graph.
"""
def alg5(list_of_locations, list_of_homes, starting_car_location, adjacency_matrix, params=[]):
    starting_car_location = list_of_locations.index(starting_car_location)
    homes_to_visit = convert_locations_to_indices(list_of_homes, list_of_locations)
    locations = list(range(len(list_of_locations)))

    not_homes = []
    for location in locations:
        if location not in homes_to_visit:
            not_homes.append(location)

    LARGE_NUMBER = 3 * 10**9
    adj_mat = copy.deepcopy(adjacency_matrix)
    for not_home in not_homes:
        for i in range(len(adj_mat)):
            if adj_mat[not_home][i] != 'x':
                adj_mat[not_home][i] += LARGE_NUMBER
            if adj_mat[i][not_home] != 'x':
                adj_mat[i][not_home] += LARGE_NUMBER


    G = adjacency_matrix_to_graph(adj_mat)[0]
    MST = nx.minimum_spanning_tree(G)
    dfs_list = list(nx.dfs_edges(MST, source=starting_car_location))

    # Construct DFS traversal list
    new_dfs_list = list(dfs_list[0])
    for i in range(1, len(dfs_list)):
        if dfs_list[i-1][1] != dfs_list[i][0]:
            new_dfs_list.extend(nx.shortest_path(MST, source=dfs_list[i-1][1], target=dfs_list[i][0])[1:])
        new_dfs_list.append(dfs_list[i][1])
    new_dfs_list.extend(nx.shortest_path(MST, source=new_dfs_list[-1], target=starting_car_location)[1:])

    # Construct drop off list
    drop_offs = {home:[home] for home in convert_locations_to_indices(list_of_homes, list_of_locations)}

    # Optimize DFS traversal
    new_dfs_list, drop_offs = optimize_graph(new_dfs_list, drop_offs, G)
     
    return new_dfs_list, drop_offs

"""
Algorithm 6.
Satish does some funky stuff with the graph then runs alg2.
"""
def alg6(list_of_locations, list_of_homes, starting_car_location, adjacency_matrix, params=[]):
    starting_car_location = list_of_locations.index(starting_car_location)
    homes_to_visit = convert_locations_to_indices(list_of_homes, list_of_locations)
    locations = list(range(len(list_of_locations)))

    not_homes = []
    for location in locations:
        if location not in homes_to_visit:
            not_homes.append(location)

    LARGE_NUMBER = 3 * 10**9
    adj_mat = copy.deepcopy(adjacency_matrix)
    for not_home in not_homes:
        for i in range(len(adj_mat)):
            if adj_mat[not_home][i] != 'x':
                adj_mat[not_home][i] += LARGE_NUMBER
            if adj_mat[i][not_home] != 'x':
                adj_mat[i][not_home] += LARGE_NUMBER


    G = adjacency_matrix_to_graph(adj_mat)[0]
    shortest = dict(nx.floyd_warshall(G))

    car_path = [starting_car_location]
    current_location = starting_car_location
    while homes_to_visit != []:
        distances_to_homes = [shortest[current_location][home] for home in homes_to_visit]
        next_location = homes_to_visit.pop(np.argmin(distances_to_homes))
        car_path.extend(nx.shortest_path(G, source=current_location, target=next_location, weight='weight')[1:])
        current_location = next_location

    car_path.extend(nx.shortest_path(G, source=current_location, target=starting_car_location, weight='weight')[1:])

    drop_offs = {home:[home] for home in convert_locations_to_indices(list_of_homes, list_of_locations)}

    # Optimize traversal
    car_path, drop_offs = optimize_graph(car_path, drop_offs, G)

    return car_path, drop_offs

"""
Algorithm 7.
Chris's algorithm.
"""
def alg7(car):
    """Going to attempt to write an algorithm that first does Dijkstra's on every node to every node and store this list. Next it finds the average edge length. We then
    drive to the home closest to rao using the shortest path. Next, for every TA that is left, we check if the distance stored from our current node to their home is leq the average edge length.
    If so, we drop them off and if not then we keep then and drive to the next cloest home, doing
    this process until we run out of TAs and then drive straight home using the shortest route.
    """
    starting_car_location = list_of_locations.index(starting_car_location)
    homes_to_visit = convert_locations_to_indices(list_of_homes, list_of_locations)
    G = adjacency_matrix_to_graph(adjacency_matrix)[0]
    shortest = dict(nx.floyd_warshall(G))
    drop_offs = []
    previous_location = list_of_locations.index(starting_car_location)

    """threshold is a variable that is reevaluated every loop and if a home is close than the threshohold, rao drops them off where they currently are"""
    threshold = 0

    car_path = [starting_car_location]
    current_location = starting_car_location
    while homes_to_visit != []:
        distances_to_homes = [shortest[current_location][home] for home in homes_to_visit]

        """First iteration threshold is just 0"""
        threshold = shortest[previous_location][current_location]
        for distance in distances_to_homes:
            if distance <= threshold:
                if current_location not in drop_offs:
                    drop_offs.append(current_location)

                """Name of location at end of edge?"""
                drop_offs[current_location].append(distance)
                homes_to_visit.pop(distance)

        next_location = homes_to_visit.pop(np.argmin(distances_to_homes))
        car_path.extend(nx.shortest_path(G, source=current_location, target=next_location, weight='weight')[1:])
        previous_location = current_location
        current_location = next_location


    """Appends path back to start"""
    car_path.extend(nx.shortest_path(G, source=current_location, target=starting_car_location, weight='weight')[1:])

    #drop_offs = {home:[home] for home in convert_locations_to_indices(list_of_homes, list_of_locations)}

    return car_path, drop_offs

def optimize_graph(car_path, drop_offs, G):
    # Find cycles in the graph and attempt to get rid of them entirely and
    # drop off TAs at the start of the cycle.
    done = False
    while not done:
        seen = {}
        done = True
        for i in range(len(car_path)):
            vertex = car_path[i]
            if vertex not in seen:
                seen[vertex] = i
            else:
                prev_ind = seen[vertex]
                seen[vertex] = i
                num_dropoffs = 0
                tas_dropped_off = []
                original_dropoff = []

                # Count and find TAs dropped off in "some_vertices"
                for j in range(prev_ind+1, i):
                    vertex_at_j = car_path[j]
                    if vertex_at_j in drop_offs:
                        tas_dropped_off_at_j = drop_offs[vertex_at_j]
                        num_dropoffs += len(tas_dropped_off_at_j)  # Maybe switch with + 1 for each location
                        tas_dropped_off.extend(tas_dropped_off_at_j)
                        original_dropoff.extend([vertex_at_j] * len(tas_dropped_off_at_j))
            
                assert len(tas_dropped_off) == num_dropoffs
                assert len(original_dropoff) == num_dropoffs
                if num_dropoffs == 0:
                    car_path[prev_ind : i] = []
                    done = False
                    break
                elif num_dropoffs == 1:
                    if car_path[prev_ind] in drop_offs:
                        drop_offs[car_path[prev_ind]].extend(tas_dropped_off)
                    else:
                        drop_offs[car_path[prev_ind]] = tas_dropped_off
                    del drop_offs[original_dropoff[0]]
                    car_path[prev_ind : i] = []
                    done = False
                    break
    # print(car_path)

    # Try to get rid of unoptimal sections of driving
    last_dropoff_index = 0
    better_car_path = [car_path[0]]
    for i in range(last_dropoff_index + 1, len(car_path)):
        if car_path[i] in drop_offs:
            better_car_path.extend(nx.shortest_path(G, source=car_path[last_dropoff_index], target=car_path[i], weight='weight')[1:])
            last_dropoff_index = i
    better_car_path.extend(nx.shortest_path(G, source=car_path[last_dropoff_index], target=car_path[-1], weight='weight')[1:])
    # print(f"After {better_car_path}")

    return better_car_path, drop_offs

def draw_graph(G):
    pos = nx.spring_layout(G)
    nx.draw(G, pos, with_labels=True)
    edge_labels = nx.get_edge_attributes(G,'distance')
    nx.draw_networkx_edge_labels(G, pos, edge_labels = edge_labels)
    nx.draw_networkx_nodes(G, pos)
    plt.show()

"""
======================================================================
   No need to change any code below this line
======================================================================
"""

"""
Convert solution with path and dropoff_mapping in terms of indices
and write solution output in terms of names to path_to_file + file_number + '.out'
"""
def convertToFile(path, dropoff_mapping, path_to_file, list_locs):
    string = ''
    for node in path:
        string += list_locs[node] + ' '
    string = string.strip()
    string += '\n'

    dropoffNumber = len(dropoff_mapping.keys())
    string += str(dropoffNumber) + '\n'
    for dropoff in dropoff_mapping.keys():
        strDrop = list_locs[dropoff] + ' '
        for node in dropoff_mapping[dropoff]:
            strDrop += list_locs[node] + ' '
        strDrop = strDrop.strip()
        strDrop += '\n'
        string += strDrop
    utils.write_to_file(path_to_file, string)

def solve_from_file(input_file, output_directory, params=[]):
    print('Processing', input_file)

    input_data = utils.read_file(input_file)
    num_of_locations, num_houses, list_locations, list_houses, starting_car_location, adjacency_matrix = data_parser(input_data)
    # print(starting_car_location)
    car_path, drop_offs = solve(list_locations, list_houses, starting_car_location, adjacency_matrix, params=params)

    basename, filename = os.path.split(input_file)
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)
    output_file = utils.input_to_output(input_file, output_directory)

    convertToFile(car_path, drop_offs, output_file, list_locations)


def solve_all(input_directory, output_directory, params=[]):
    input_files = utils.get_files_with_extension(input_directory, 'in')

    for input_file in input_files:
        solve_from_file(input_file, output_directory, params=params)


if __name__=="__main__":
    parser = argparse.ArgumentParser(description='Parsing arguments')
    parser.add_argument('--all', action='store_true', help='If specified, the solver is run on all files in the input directory. Else, it is run on just the given input file')
    parser.add_argument('input', type=str, help='The path to the input file or directory')
    parser.add_argument('output_directory', type=str, nargs='?', default='.', help='The path to the directory where the output should be written')
    parser.add_argument('params', nargs=argparse.REMAINDER, help='Extra arguments passed in')
    args = parser.parse_args()
    output_directory = args.output_directory
    if args.all:
        input_directory = args.input
        solve_all(input_directory, output_directory, params=args.params)
    else:
        input_file = args.input
        solve_from_file(input_file, output_directory, params=args.params)
